export interface User {
    userId?: number,
    id?: number,
    title?: string,
    body?: string
}